Example data which can be read and manipulated using
[hadron](https://github.com/HISKP-LQCD/hadron).
